import random

WORDS = [
    "apple",
    "robot",
    "piano",
    "mount",
    "spark",
]
MAX_INCORRECT = 6


def display_progress(word, guessed_letters):
    return " ".join(letter if letter in guessed_letters else "_" for letter in word)


def get_valid_guess(guessed_letters):
    while True:
        guess = input("Guess a letter: ").strip().lower()
        if len(guess) != 1 or not guess.isalpha():
            print("Please enter exactly one letter.")
        elif guess in guessed_letters:
            print("You already guessed that letter.")
        else:
            return guess


def play_round():
    secret_word = random.choice(WORDS)
    guessed_letters = set()
    incorrect_guesses = 0

    print("\nWelcome to Hangman!")
    print(f"The word has {len(secret_word)} letters.")

    while incorrect_guesses < MAX_INCORRECT:
        progress = display_progress(secret_word, guessed_letters)
        print("\nWord:", progress)
        print(f"Incorrect guesses left: {MAX_INCORRECT - incorrect_guesses}")
        print("Guessed letters:", " ".join(sorted(guessed_letters)) if guessed_letters else "none")

        guess = get_valid_guess(guessed_letters)
        guessed_letters.add(guess)

        if guess in secret_word:
            print("Good guess!")
            if all(letter in guessed_letters for letter in secret_word):
                print("\nYou won! The word was:", secret_word)
                return
        else:
            incorrect_guesses += 1
            print("That letter is not in the word.")

    print("\nGame over. You ran out of guesses.")
    print("The word was:", secret_word)


def main():
    while True:
        play_round()
        again = input("\nPlay again? (y/n): ").strip().lower()
        if again != "y":
            print("Thanks for playing Hangman!")
            break


if __name__ == "__main__":
    main()
